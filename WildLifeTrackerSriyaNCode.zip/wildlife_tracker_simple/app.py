# io lets us take raw bytes from the database and send them back like a file
import io

# os lets us access environment variables like DB name, username, password, and secret key
import os

# psycopg2 is the library that connects Python/Flask to PostgreSQL
import psycopg2

# These are the Flask pieces we need for routing, templates, forms, redirects, messages, and file sending
from flask import (
    Flask,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    url_for,
)

# Bcrypt is used to hash passwords securely instead of storing plain-text passwords
from flask_bcrypt import Bcrypt

# Flask-Login handles login sessions and protected routes
from flask_login import (
    LoginManager,
    UserMixin,
    current_user,
    login_required,
    login_user,
    logout_user,
)

# Create the Flask app
app = Flask(__name__)

# Secret key is needed for sessions and flash messages
# It tries to get a secret key from environment variables first
# If one is not found, it uses this fallback string
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'change_this_secret_key')

# Set up Flask-Login
login_manager = LoginManager(app)

# If a user tries to open a protected page without logging in,
# Flask-Login will redirect them to the route named 'login'
login_manager.login_view = 'login'

# Set up bcrypt so we can hash and check passwords
bcrypt = Bcrypt(app)



# Database connection helper

def get_db_connection():
    """Open a connection to Postgres using environment variables."""

    # Connect to the drhscit.org Postgres server
    # The specific database name, username, and password are stored in environment variables
    return psycopg2.connect(
        host='drhscit.org',
        database=os.environ['DB'],
        user=os.environ['DB_UN'],
        password=os.environ['DB_PW']
    )



# Flask-Login user object

class User(UserMixin):
    # This class represents one logged-in user
    # UserMixin gives us useful Flask-Login features like:
    # is_authenticated, is_active, get_id(), etc.
    def __init__(self, id, username, firstname, lastname, email, isadmin, isreadonly, password_hash):
        # Store the user's id from the database
        self.id = id

        # Store the username
        self.username = username

        # Store first and last name
        self.firstname = firstname
        self.lastname = lastname

        # Store email
        self.email = email

        # Store permission fields
        # isadmin = can access admin features
        # isreadonly = can log in but should not modify content
        self.isadmin = isadmin
        self.isreadonly = isreadonly

        # Store the hashed password from the database
        # This is NOT the plain password
        self.password_hash = password_hash


@login_manager.user_loader
def load_user(user_id):
    """Load the currently logged-in user from ce_users."""

    # Flask-Login stores the user id in the session
    # Later, it calls this function to reload that user from the database

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Look up the user in ce_users using their id
    cur.execute(
        'SELECT id, username, firstname, lastname, email, password_hash, isadmin, isreadonly '
        'FROM ce_users WHERE id = %s',
        (user_id,)
    )

    # Fetch one matching user
    user = cur.fetchone()

    # Close database connection
    cur.close()
    conn.close()

    # If a user was found, return a User object
    if user:
        return User(
            id=user[0], username=user[1], firstname=user[2], lastname=user[3],
            email=user[4], password_hash=user[5], isadmin=user[6], isreadonly=user[7]
        )

    # If no user was found, return None
    return None



# Home page
@app.route('/')
def index():
    """Show all sightings with category, uploader, and favorite count."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # This query gets all sightings and joins extra tables so we can show more info
    # s = sightings table
    # c = categories table
    # u = ce_users table
    # f = favorites table
    #
  
    # s.id = sighting id
    # s.title = title/name of the sighting
    # s.location = where it was seen
    # s.description = user's written description
    # s.sighting_date = date of sighting
    # s.image = raw image/pdf bytes
    # s.mimetype = tells browser what kind of file it is
    # c.name = category name
    # u.username = who uploaded it
    # COUNT(f.user_id) = number of users who favorited it
    cur.execute('''
        SELECT s.id,
               s.title,
               s.location,
               s.description,
               s.sighting_date,
               s.image,
               s.mimetype,
               c.name AS category_name,
               u.username,
               COUNT(f.user_id) AS favorite_count
        FROM sightings s
        JOIN categories c ON s.category_id = c.id
        JOIN ce_users u ON s.user_id = u.id
        LEFT JOIN favorites f ON s.id = f.sighting_id
        GROUP BY s.id, c.name, u.username
        ORDER BY s.id DESC
    ''')

    # Get all the rows from the query
    sightings = cur.fetchall()

    # Close database connection
    cur.close()
    conn.close()

    # Send all sightings to index.html
    return render_template('index.html', sightings=sightings)



# Authentication routes

@app.route('/register', methods=('GET', 'POST'))
def register():
    """Create a normal user account."""

    # If the form was submitted
    if request.method == 'POST':
        # Get all form values from the registration form
        firstname = request.form['firstname']
        lastname = request.form['lastname']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Turn the password into a secure hash
        # This is what gets stored in the database instead of the real password
        pw_hash = bcrypt.generate_password_hash(password).decode('utf-8')

        # Open database connection
        conn = get_db_connection()
        cur = conn.cursor()

        try:
            # Insert the new user into ce_users
            # Notice that isadmin and isreadonly are not included here,
            # so this creates a normal user by default
            cur.execute(
                'INSERT INTO ce_users (username, firstname, lastname, email, password_hash) '
                'VALUES (%s, %s, %s, %s, %s)',
                (username, firstname, lastname, email, pw_hash)
            )

            # Save the insert
            conn.commit()

            # Let the user know account creation worked
            flash('Account created. Please log in.')

            # Send them to login page
            return redirect(url_for('login'))

        except (Exception, psycopg2.DatabaseError) as error:
            # If something goes wrong, undo the insert
            conn.rollback()

            # Show the error message on screen
            flash('Error: ' + str(error))

        finally:
            # Always close connection whether the insert worked or failed
            cur.close()
            conn.close()

    # If it was a GET request, just show the registration page
    return render_template('register.html')


@app.route('/login', methods=('GET', 'POST'))
def login():
    """Log the user in using bcrypt password checking."""

    # If the login form was submitted
    if request.method == 'POST':
        # Get username and password typed by the user
        username = request.form['username']
        password = request.form['password']

        # Open database connection
        conn = get_db_connection()
        cur = conn.cursor()

        # Look for a user with the submitted username
        cur.execute(
            'SELECT id, username, firstname, lastname, email, password_hash, isadmin, isreadonly '
            'FROM ce_users WHERE username = %s',
            (username,)
        )

        # Get one user row
        user = cur.fetchone()

        # Close database connection
        cur.close()
        conn.close()

        # user[5] is the stored password hash from the database
        # bcrypt.check_password_hash checks whether the typed password matches the stored hash
        if user and bcrypt.check_password_hash(user[5], password.encode('utf-8')):
            # Build a User object for Flask-Login
            user_obj = User(
                id=user[0], username=user[1], firstname=user[2], lastname=user[3],
                email=user[4], password_hash=user[5], isadmin=user[6], isreadonly=user[7]
            )

            # Log the user in for this session
            login_user(user_obj)

            # If Flask-Login saved the page the user originally wanted,
            # redirect them there after login
            nxt = request.args.get('next')
            if nxt:
                return redirect(nxt or url_for('index'))

            # Otherwise send them to the home page
            return redirect(url_for('index'))
        else:
            # If username/password was wrong, show error
            flash('Login unsuccessful. Please check username and password.')

    # If it was a GET request, just show the login page
    return render_template('login.html')


@app.route('/logout')
def logout():
    # End the current login session
    logout_user()

    # Send the user back to login page
    return redirect(url_for('login'))



# Create sighting

@app.route('/create', methods=('GET', 'POST'))
@login_required
def create():
    """Create a new sighting with optional image/pdf upload and tag links."""

    # This route is protected with @login_required,
    # so only logged-in users can access it

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Get all categories so they can appear in the form dropdown
    cur.execute('SELECT id, name FROM categories ORDER BY name')
    categories = cur.fetchall()

    # Get all tags so they can appear as checkboxes
    cur.execute('SELECT id, name FROM tags ORDER BY name')
    tags = cur.fetchall()

    # If the form was submitted
    if request.method == 'POST':
        # If the current user is read-only, block them from adding sightings
        if current_user.isreadonly:
            flash('Read-only users cannot add sightings.')
            cur.close()
            conn.close()
            return redirect(url_for('index'))

        # Get form data
        title = request.form['title']
        location = request.form['location']
        description = request.form['description']
        sighting_date = request.form['date']
        category_id = request.form['category_id']

        # getlist is used because multiple tag checkboxes can be selected
        chosen_tags = request.form.getlist('tags')

        # Get the uploaded file from the form
        file = request.files['theImage']

        try:
            # If the user uploaded a file and the filename is not blank
            if file and file.filename != '':
                # Insert the sighting including image bytes and mimetype
                cur.execute(
                    'INSERT INTO sightings (title, location, description, sighting_date, image, mimetype, user_id, category_id) '
                    'VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id',
                    (title, location, description, sighting_date, file.read(), file.mimetype, current_user.id, category_id)
                )
            else:
                # Insert the sighting without a file
                cur.execute(
                    'INSERT INTO sightings (title, location, description, sighting_date, user_id, category_id) '
                    'VALUES (%s, %s, %s, %s, %s, %s) RETURNING id',
                    (title, location, description, sighting_date, current_user.id, category_id)
                )

            # Get the id of the sighting we just inserted
            sighting_id = cur.fetchone()[0]

            # Add rows to the many-to-many join table sighting_tags
            # This connects one sighting to as many tags as the user selected
            for tag_id in chosen_tags:
                cur.execute(
                    'INSERT INTO sighting_tags (sighting_id, tag_id) VALUES (%s, %s)',
                    (sighting_id, tag_id)
                )

            # Save all inserts
            conn.commit()

            # Success message
            flash('Sighting added!')

            # Go back to home page
            return redirect(url_for('index'))

        except (Exception, psycopg2.DatabaseError) as error:
            # If anything failed, undo the inserts
            conn.rollback()

            # Show the error
            flash('Error: ' + str(error))

    # Close connection before rendering form
    cur.close()
    conn.close()

    # Show create form
    return render_template('create.html', categories=categories, tags=tags)


# Single sighting page

@app.route('/sighting/<int:sighting_id>', methods=('GET', 'POST'))
def view_sighting(sighting_id):
    """Show one sighting, its comments, and its tags. Logged-in users can comment."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # If the page was submitted with a comment form
    # and the user is logged in
    # and the user is not read-only
    if request.method == 'POST' and current_user.is_authenticated and not current_user.isreadonly:
        # Get the comment text from the form
        comment_text = request.form['comment_text']

        # Insert the comment into the comments table
        # This is a one-to-many relationship:
        # one sighting can have many comments
        # one user can also make many comments
        cur.execute(
            'INSERT INTO comments (comment_text, user_id, sighting_id) VALUES (%s, %s, %s)',
            (comment_text, current_user.id, sighting_id)
        )

        # Save comment
        conn.commit()

        # Let the user know it worked
        flash('Comment added!')

        # Close connection
        cur.close()
        conn.close()

        # Redirect back to the same page so the new comment shows up
        return redirect(url_for('view_sighting', sighting_id=sighting_id))

    # Get one sighting and extra info about it
    # This query joins:
    # sightings
    # categories
    # ce_users
    cur.execute('''
        SELECT s.id, s.title, s.location, s.description, s.sighting_date, s.image, s.mimetype,
               c.name, u.username, u.firstname, u.lastname
        FROM sightings s
        JOIN categories c ON s.category_id = c.id
        JOIN ce_users u ON s.user_id = u.id
        WHERE s.id = %s
    ''', (sighting_id,))
    sighting = cur.fetchone()

    # Get all tags connected to this sighting
    # This uses the many-to-many join table sighting_tags
    cur.execute('''
        SELECT t.name
        FROM tags t
        JOIN sighting_tags st ON t.id = st.tag_id
        WHERE st.sighting_id = %s
        ORDER BY t.name
    ''', (sighting_id,))
    tags = cur.fetchall()

    # Get all comments for this sighting
    # Join with ce_users so we can show who posted each comment
    cur.execute('''
        SELECT cm.comment_text, u.username
        FROM comments cm
        JOIN ce_users u ON cm.user_id = u.id
        WHERE cm.sighting_id = %s
        ORDER BY cm.id DESC
    ''', (sighting_id,))
    comments = cur.fetchall()

    # Track whether the current user already favorited this sighting
    favorited = False

    # Only check favorites if the user is logged in
    if current_user.is_authenticated:
        cur.execute(
            'SELECT * FROM favorites WHERE user_id = %s AND sighting_id = %s',
            (current_user.id, sighting_id)
        )
        favorited = cur.fetchone() is not None

    # Close connection
    cur.close()
    conn.close()

    # Render the single sighting page
    return render_template('view_sighting.html', sighting=sighting, tags=tags, comments=comments, favorited=favorited)



# Display uploaded image/pdf

@app.route('/image/<int:image_id>')
def get_image(image_id):
    """Display the uploaded file using the same send_file/io.BytesIO style you wanted."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Get the raw file bytes and mimetype from the sightings table
    cur.execute('SELECT image, mimetype FROM sightings WHERE id = %s', (image_id,))
    data = cur.fetchone()

    # Close connection
    cur.close()
    conn.close()

    # data[0] = raw bytes of file
    # data[1] = mimetype, like image/png or application/pdf
    
    # io.BytesIO turns the raw bytes into something Flask can send as a file
    # send_file sends it to the browser
    return send_file(io.BytesIO(data[0]), mimetype=data[1])



# Edit sighting

@app.route('/edit/<int:sighting_id>', methods=('GET', 'POST'))
@login_required
def edit(sighting_id):
    """Edit a sighting. Only the owner or an admin can edit it."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # First find the owner of the sighting
    cur.execute('SELECT user_id FROM sightings WHERE id = %s', (sighting_id,))
    owner = cur.fetchone()

    # If no sighting exists, or the current user is not the owner
    # and is not an admin, block access
    if not owner or (current_user.id != owner[0] and not current_user.isadmin):
        cur.close()
        conn.close()
        flash('You do not have permission to edit that sighting.')
        return redirect(url_for('index'))

    # Get categories for the edit form dropdown
    cur.execute('SELECT id, name FROM categories ORDER BY name')
    categories = cur.fetchall()

    # Get the full existing sighting record to prefill the form
    cur.execute('SELECT * FROM sightings WHERE id = %s', (sighting_id,))
    sighting = cur.fetchone()

    # If the form was submitted
    if request.method == 'POST':
        # Get updated form values
        title = request.form['title']
        location = request.form['location']
        description = request.form['description']
        sighting_date = request.form['date']
        category_id = request.form['category_id']

        # Update the sighting in the database
        cur.execute(
            'UPDATE sightings SET title = %s, location = %s, description = %s, sighting_date = %s, category_id = %s '
            'WHERE id = %s',
            (title, location, description, sighting_date, category_id, sighting_id)
        )

        # Save update
        conn.commit()

        # Close connection
        cur.close()
        conn.close()

        # Success message
        flash('Sighting updated!')

        # Return to the single sighting page
        return redirect(url_for('view_sighting', sighting_id=sighting_id))

    # If GET request, close connection and show edit page
    cur.close()
    conn.close()
    return render_template('edit.html', sighting=sighting, categories=categories)



# Delete sighting

@app.route('/delete/<int:sighting_id>')
@login_required
def delete(sighting_id):
    """Delete a sighting. Owner or admin only."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Find owner of the sighting
    cur.execute('SELECT user_id FROM sightings WHERE id = %s', (sighting_id,))
    owner = cur.fetchone()

    # Only allow delete if user is the owner or an admin
    if not owner or (current_user.id != owner[0] and not current_user.isadmin):
        cur.close()
        conn.close()
        flash('You do not have permission to delete that sighting.')
        return redirect(url_for('index'))

    # Delete the sighting
    cur.execute('DELETE FROM sightings WHERE id = %s', (sighting_id,))

    # Save delete
    conn.commit()

    # Close connection
    cur.close()
    conn.close()

    # Success message
    flash('Sighting deleted.')

    # Return to home page
    return redirect(url_for('index'))



# Favorite / unfavorite routes

@app.route('/favorite/<int:sighting_id>')
@login_required
def favorite(sighting_id):
    """Many-to-many example: one user can favorite many sightings."""

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Check if this user already favorited this sighting
    cur.execute('SELECT * FROM favorites WHERE user_id = %s AND sighting_id = %s', (current_user.id, sighting_id))
    already = cur.fetchone()

    # If not already favorited, insert a row into favorites
    # favorites is a many-to-many join table:
    # one user -> many sightings
    # one sighting -> many users
    if not already:
        cur.execute('INSERT INTO favorites (user_id, sighting_id) VALUES (%s, %s)', (current_user.id, sighting_id))
        conn.commit()

    # Close connection
    cur.close()
    conn.close()

    # Return to that sighting's page
    return redirect(url_for('view_sighting', sighting_id=sighting_id))


@app.route('/unfavorite/<int:sighting_id>')
@login_required
def unfavorite(sighting_id):
    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Remove the favorite row for this user and sighting
    cur.execute('DELETE FROM favorites WHERE user_id = %s AND sighting_id = %s', (current_user.id, sighting_id))

    # Save delete
    conn.commit()

    # Close connection
    cur.close()
    conn.close()

    # Return to that sighting's page
    return redirect(url_for('view_sighting', sighting_id=sighting_id))



# Admin panel

@app.route('/admin')
@login_required
def admin_panel():
    """Admin-only page with all sightings and users."""

    # Only admins can access this page
    if not current_user.isadmin:
        flash('Admins only.')
        return redirect(url_for('index'))

    # Open database connection
    conn = get_db_connection()
    cur = conn.cursor()

    # Get all sightings with username and date for moderation view
    cur.execute('''
        SELECT s.id, s.title, u.username, s.sighting_date
        FROM sightings s
        JOIN ce_users u ON s.user_id = u.id
        ORDER BY s.id DESC
    ''')
    sightings = cur.fetchall()

    # Get all users so the admin can view accounts/roles
    cur.execute('SELECT id, username, firstname, lastname, isadmin, isreadonly FROM ce_users ORDER BY id')
    users = cur.fetchall()

    # Close connection
    cur.close()
    conn.close()

    # Show admin page
    return render_template('admin.html', sightings=sightings, users=users)


# Run the Flask app in debug mode when app.py is executed directly
if __name__ == '__main__':
    app.run(debug=True)
