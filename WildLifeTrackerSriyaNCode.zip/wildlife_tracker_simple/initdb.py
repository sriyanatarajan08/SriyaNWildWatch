# os lets us access environment variables for DB name, username, and password
import os

# psycopg2 connects Python to PostgreSQL
import psycopg2

# Bcrypt is used to hash passwords before storing them
from flask_bcrypt import Bcrypt

# Create bcrypt object
bcrypt = Bcrypt()


# Function to connect to the database
def get_db_connection():
    return psycopg2.connect(
        host='drhscit.org',
        database=os.environ['DB'],
        user=os.environ['DB_UN'],
        password=os.environ['DB_PW']
    )


# Open the database connection
conn = get_db_connection()

# Create a cursor so SQL commands can be executed
cur = conn.cursor()

try:
    # -----------------------------
    # Users table for authentication
    # -----------------------------
    # This table stores all users for login
    # It includes username, password hash, name, email,
    # and permission columns for admin and readonly
    cur.execute('''
        CREATE TABLE IF NOT EXISTS ce_users (
            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            firstname VARCHAR(50) NOT NULL,
            lastname VARCHAR(50) NOT NULL,
            email VARCHAR(100),
            password_hash VARCHAR(128) NOT NULL,
            isadmin BOOLEAN DEFAULT FALSE,
            isreadonly BOOLEAN DEFAULT FALSE,
            CONSTRAINT perm_ck CHECK ((isadmin = true AND isreadonly = true) = false)
        );
    ''')

    # -----------------------------
    # Category table
    # One category can have many sightings
    # -----------------------------
    # This stores possible category choices like Bird or Mammal
    cur.execute('''
        CREATE TABLE IF NOT EXISTS categories (
            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            name VARCHAR(50) UNIQUE NOT NULL
        );
    ''')

    # -----------------------------
    # Main sightings table
    # One user can create many sightings
    # -----------------------------
    # This is the main table for wildlife posts
    # It stores basic info plus optional image/pdf upload
    # user_id connects each sighting to the person who posted it
    # category_id connects each sighting to one category
    cur.execute('''
        CREATE TABLE IF NOT EXISTS sightings (
            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            title VARCHAR(100) NOT NULL,
            location VARCHAR(150) NOT NULL,
            description TEXT NOT NULL,
            sighting_date DATE NOT NULL,
            image BYTEA,
            mimetype VARCHAR(100),
            user_id INTEGER NOT NULL REFERENCES ce_users(id) ON DELETE CASCADE,
            category_id INTEGER NOT NULL REFERENCES categories(id)
        );
    ''')

   
    # Comments table
    # One sighting can have many comments
  
    # This table stores comments made on sightings
    # Each comment belongs to one user and one sighting
    cur.execute('''
        CREATE TABLE IF NOT EXISTS comments (
            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            comment_text TEXT NOT NULL,
            user_id INTEGER NOT NULL REFERENCES ce_users(id) ON DELETE CASCADE,
            sighting_id INTEGER NOT NULL REFERENCES sightings(id) ON DELETE CASCADE
        );
    ''')


    # Tags table
 
    # This stores all possible tag names
    # Example: Rare, Forest, River
    cur.execute('''
        CREATE TABLE IF NOT EXISTS tags (
            id INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
            name VARCHAR(50) UNIQUE NOT NULL
        );
    ''')

    # -----------------------------
    # Many-to-many: sightings & tags
    # -----------------------------
    # This join table connects sightings and tags
    # One sighting can have many tags
    # One tag can be attached to many sightings
    cur.execute('''
        CREATE TABLE IF NOT EXISTS sighting_tags (
            sighting_id INTEGER REFERENCES sightings(id) ON DELETE CASCADE,
            tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
            PRIMARY KEY (sighting_id, tag_id)
        );
    ''')

   
    # Many-to-many: users & favorite sightings
 
    # This join table tracks which users favorited which sightings
    # One user can favorite many sightings
    # One sighting can be favorited by many users
    cur.execute('''
        CREATE TABLE IF NOT EXISTS favorites (
            user_id INTEGER REFERENCES ce_users(id) ON DELETE CASCADE,
            sighting_id INTEGER REFERENCES sightings(id) ON DELETE CASCADE,
            PRIMARY KEY (user_id, sighting_id)
        );
    ''')

    # Add starter categories
    # ON CONFLICT DO NOTHING prevents duplicate inserts if script is run again
    # used https://stackoverflow.com/questions/48923456/postgres-insert-on-conflict-do-nothing-vs-select-insert-query
    cur.execute("INSERT INTO categories (name) VALUES ('Bird'), ('Mammal'), ('Reptile'), ('Amphibian'), ('Insect') ON CONFLICT DO NOTHING;")

    # Add starter tags
    cur.execute("INSERT INTO tags (name) VALUES ('Rare'), ('Backyard'), ('River'), ('Forest'), ('Night') ON CONFLICT DO NOTHING;")

    # Add default admin account if it does not already exist
    # First hash the password 'admin123'
    admin_hash = bcrypt.generate_password_hash('admin123').decode('utf-8')

    # Insert the admin user
    # isadmin = True means this account has admin access
    # isreadonly = False means admin is allowed to make changes
    cur.execute('''
        INSERT INTO ce_users (username, firstname, lastname, email, password_hash, isadmin, isreadonly)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        ON CONFLICT (username) DO NOTHING;
    ''', ('admin', 'Admin', 'User', 'admin@example.com', admin_hash, True, False))

    # Save all table creations and inserts
    conn.commit()

    # Print success messages in terminal
    print('Database setup complete.')
    print('Default admin login -> username: admin   password: admin123')

except (Exception, psycopg2.DatabaseError) as error:
    # If something fails, undo changes
    conn.rollback()

    # Print the error in terminal
    print('Error:', error)

finally:
    # Always close cursor and connection
    cur.close()
    conn.close()
